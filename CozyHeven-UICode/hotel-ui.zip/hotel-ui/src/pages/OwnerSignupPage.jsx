import { useState } from "react"
import { useNavigate, Link } from "react-router-dom"
import axios from "axios"
import "../styles/pages.css"
import "../styles/components.css"

const BASE = "http://localhost:8080"

const StarPicker = ({ value, onChange }) => (
  <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
    {[1, 2, 3, 4, 5].map(s => (
      <button
        key={s}
        type="button"
        onClick={() => onChange(s)}
        style={{
          fontSize: 28, background: "none", border: "none", cursor: "pointer",
          color: s <= value ? "var(--gold)" : "var(--border2)",
          transition: "color .15s",
        }}
      >★</button>
    ))}
    <span style={{ fontSize: 13, color: "var(--muted)", alignSelf: "center", marginLeft: 4 }}>
      {value} star{value !== 1 ? "s" : ""}
    </span>
  </div>
)

const OwnerSignupPage = () => {
  const navigate = useNavigate()

  const [owner, setOwner] = useState({
    name: "", username: "", email: "", password: "", confirmPassword: "",
  })

  const [hotel, setHotel] = useState({
    hotelName: "", location: "", description: "", ratings: 3,
  })

  const [loading, setLoading] = useState(false)
  const [errMsg,  setErrMsg]  = useState("")
  const [success, setSuccess] = useState(false)

  const setO = (field) => (e) => setOwner(o => ({ ...o, [field]: e.target.value }))
  const setH = (field) => (e) => setHotel(h => ({ ...h, [field]: e.target.value }))

  const validate = () => {
    if (!owner.name.trim())                       return "Full name is required."
    if (!owner.username.trim())                   return "Username is required."
    if (!owner.email.trim())                      return "Email is required."
    if (owner.password.length < 6)                return "Password must be at least 6 characters."
    if (owner.password !== owner.confirmPassword) return "Passwords do not match."
    if (!hotel.hotelName.trim())                  return "Hotel name is required."
    if (!hotel.location.trim())                   return "Hotel location is required."
    if (hotel.ratings < 1 || hotel.ratings > 5)  return "Rating must be between 1 and 5."
    return null
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErrMsg("")
    const err = validate()
    if (err) { setErrMsg(err); return }

    setLoading(true)
    try {
      await axios.post(BASE + "/api/hotel/owner/add", {
        name:        owner.name.trim(),
        username:    owner.username.trim(),
        email:       owner.email.trim(),
        password:    owner.password,
        hotelName:   hotel.hotelName.trim(),
        location:    hotel.location.trim(),
        description: hotel.description.trim(),
        ratings:     Number(hotel.ratings),
      })
      setSuccess(true)
    } catch (err) {
      setErrMsg(
        err.response?.data?.message ||
        err.response?.data?.error   ||
        JSON.stringify(err.response?.data) ||
        "Registration failed. Please try again."
      )
    } finally {
      setLoading(false)
    }
  }

  /* ── Success screen ── */
  if (success) {
    return (
      <div className="page-fade" style={{ maxWidth: 540, margin: "80px auto", padding: "0 24px", textAlign: "center" }}>
        <div style={{
          width: 80, height: 80, borderRadius: "50%",
          background: "var(--green-bg)", display: "flex", alignItems: "center",
          justifyContent: "center", fontSize: 36, margin: "0 auto 24px",
          border: "2px solid var(--green)",
        }}>✓</div>
        <h2 className="section-h" style={{ fontSize: 28 }}>Registration Successful!</h2>
        <p style={{ fontSize: 14, color: "var(--muted)", margin: "12px 0 8px", lineHeight: 1.7 }}>
          Your hotel owner account has been created with <strong>{hotel.hotelName}</strong>.<br />
          Sign in and add more hotels from your dashboard.
        </p>
        <button className="btn-primary" style={{ padding: "13px 32px", marginTop: 24 }} onClick={() => navigate("/")}>
          Go to Sign In →
        </button>
      </div>
    )
  }

  /* ── Main form ── */
  return (
    <div className="page-fade" style={{ maxWidth: 640, margin: "48px auto", padding: "0 24px 64px" }}>

      {/* Header */}
      <div style={{ marginBottom: 32, textAlign: "center" }}>
        <Link to="/" style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, color: "var(--ink)", textDecoration: "none" }}>
          Cozy<span style={{ color: "var(--gold)" }}>Heven</span>
        </Link>
        <div style={{ marginTop: 16 }}>
          <span className="section-tag">Hotel Partner</span>
          <h1 className="section-h" style={{ fontSize: 28, marginTop: 8 }}>List Your Hotel</h1>
          <p style={{ fontSize: 14, color: "var(--muted)", marginTop: 8 }}>
            Create your hotel owner account and register your first property.
          </p>
        </div>
      </div>

      {errMsg && <div className="alert alert-danger" style={{ marginBottom: 20 }}>{errMsg}</div>}

      <form onSubmit={handleSubmit}>

        {/* ── Owner details ── */}
        <div className="card" style={{ padding: "24px", marginBottom: 20 }}>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 17, fontWeight: 600, marginBottom: 20, paddingBottom: 12, borderBottom: "1px solid var(--border)" }}>
            👤 Your Account Details
          </div>

          <div className="form-group" style={{ marginBottom: 14 }}>
            <label className="lbl">Full Name *</label>
            <input className="input" placeholder="Ramesh Kumar" value={owner.name} onChange={setO("name")} />
          </div>

          <div className="form-grid" style={{ marginBottom: 14 }}>
            <div className="form-group">
              <label className="lbl">Username *</label>
              <input className="input" placeholder="ramesh_hotels" value={owner.username} onChange={setO("username")} minLength={3} maxLength={20} />
            </div>
            <div className="form-group">
              <label className="lbl">Email *</label>
              <input className="input" type="email" placeholder="ramesh@hotel.com" value={owner.email} onChange={setO("email")} />
            </div>
          </div>

          <div className="form-grid">
            <div className="form-group">
              <label className="lbl">Password *</label>
              <input className="input" type="password" placeholder="Min. 6 characters" value={owner.password} onChange={setO("password")} />
            </div>
            <div className="form-group">
              <label className="lbl">Confirm Password *</label>
              <input className="input" type="password" placeholder="Repeat password" value={owner.confirmPassword} onChange={setO("confirmPassword")} />
            </div>
          </div>
        </div>

        {/* ── Hotel details ── */}
        <div className="card" style={{ padding: "24px", marginBottom: 20 }}>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 17, fontWeight: 600, marginBottom: 20, paddingBottom: 12, borderBottom: "1px solid var(--border)" }}>
            🏨 Your First Hotel
          </div>

          <div className="form-grid" style={{ marginBottom: 14 }}>
            <div className="form-group">
              <label className="lbl">Hotel Name *</label>
              <input className="input" placeholder="The Grand Ramesh" value={hotel.hotelName} onChange={setH("hotelName")} />
            </div>
            <div className="form-group">
              <label className="lbl">Location *</label>
              <input className="input" placeholder="Chennai, Tamil Nadu" value={hotel.location} onChange={setH("location")} />
            </div>
          </div>

          <div className="form-group" style={{ marginBottom: 14 }}>
            <label className="lbl">Description</label>
            <textarea
              className="textarea" rows={3}
              placeholder="Tell guests what makes your hotel special..."
              value={hotel.description}
              onChange={setH("description")}
            />
          </div>

          <div className="form-group">
            <label className="lbl">Star Rating (1–5)</label>
            <StarPicker value={hotel.ratings} onChange={v => setHotel(h => ({ ...h, ratings: v }))} />
          </div>
        </div>

        <p style={{ fontSize: 12, color: "var(--muted)", textAlign: "center", marginBottom: 12 }}>
          💡 You can add more hotels from your dashboard after signing in.
        </p>

        {/* ── Submit ── */}
        <button
          type="submit"
          className="btn-primary"
          style={{ width: "100%", padding: "15px", fontSize: 15 }}
          disabled={loading}
        >
          {loading ? "Creating your account…" : "Create Account & Register Hotel →"}
        </button>

        <div style={{ textAlign: "center", marginTop: 16, fontSize: 13, color: "var(--muted)" }}>
          Already have an account?{" "}
          <button type="button" style={{ background: "none", border: "none", color: "var(--gold)", fontWeight: 600, cursor: "pointer", fontSize: 13 }} onClick={() => navigate("/")}>
            Sign in here
          </button>
        </div>

        <div style={{ textAlign: "center", marginTop: 8, fontSize: 12, color: "var(--muted)" }}>
          Are you a guest?{" "}
          <button type="button" style={{ background: "none", border: "none", color: "var(--gold)", fontWeight: 600, cursor: "pointer", fontSize: 12 }} onClick={() => navigate("/")}>
            Guest registration →
          </button>
        </div>

      </form>
    </div>
  )
}

export default OwnerSignupPage